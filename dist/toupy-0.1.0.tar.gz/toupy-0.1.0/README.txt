description of the package - should be written in ReST or Markdown (for PyPi)
